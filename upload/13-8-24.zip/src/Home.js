import React from 'react'
import First from './first'
import './style.css';

export default function Home() {
let obj= {
    color:"blue",
    backgroundColor:"black"
}   //internal


  return (
      
    <div className='box'>
      <First/>

        {/*inline*/}
        <h1 style={{backgroundColor:"red", color:"white"}}>This is home page</h1>
        <h2 style={obj}>My name is Mridul</h2>
        

    </div>


  )
}

