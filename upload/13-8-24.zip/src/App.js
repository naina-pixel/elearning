import First from "./first";
import Home from "./Home";


function App() {
  return (
          <div>
            {/* <First></First> */}
            {/* <First/> */}
            <Home/>
          </div>
  );
}

export default App;
