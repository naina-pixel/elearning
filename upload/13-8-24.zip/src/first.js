import React from "react"

function First(){

    return(
       <React.Fragment>
          <h1>my first page</h1>
          <h2>nbfghbgf</h2>
       </React.Fragment>

       

    )

}

export default First